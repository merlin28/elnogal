# Despliegue de tu propia copia — Encuesta de Daños por Sismo

Esta es una copia del sitio de la Alianza de Educación Rural
(`alianzaeducacionrural.github.io/diagnosticoafectaciones`), lista para que
la conectes a **tu propio** backend de Google (Sheet, carpeta de Drive y
proyecto de Apps Script). Ningún dato ni credencial del proyecto original
quedó en estos archivos — hay valores marcados con `TODO` que debes
completar tú, en tu propia cuenta de Google.

## Resumen de lo que necesitas crear (todo gratis, en tu cuenta de Google)

1. Un **Google Sheet** para guardar los registros (vacío, tú le pones el nombre).
2. Una **carpeta de Google Drive** donde se guardarán las fotos/videos/documentos.
3. Un **proyecto de Google Apps Script** (el backend) desplegado como Web App.
4. Tu **Sheet SIMAT** propio (ya lo tienes) — con una pestaña con el catálogo
   de sedes, matrícula y código DANE.
5. Un **repositorio de GitHub** con GitHub Pages activado (el frontend).

---

## Paso 1 — Crear el Sheet de resultados

1. Ve a sheets.google.com → Sheet en blanco.
2. Nómbralo como quieras, ej. "Daños por sismo — Registro".
3. Copia el ID de la URL: `docs.google.com/spreadsheets/d/`**`ESTE_ID`**`/edit`.
4. Dentro de este Sheet, crea (si vas a usar el cruce de conectividad) una
   pestaña llamada `Conectividad` con columnas:
   `Municipio | Institución | Sede | DANE Sede | Conectividad (Si/No)`.
   Si no la tienes lista todavía, no pasa nada — `inicializar()` (paso 3)
   no la crea, pero el sistema funciona igual, solo esa columna queda vacía.

No hace falta crear las pestañas `registros`, `padrinos` ni `asignacion` a
mano — las crea automáticamente la función `inicializar()` del backend.

## Paso 2 — Crear la carpeta de Drive para evidencias

1. En drive.google.com, crea una carpeta nueva.
2. Ábrela y copia el ID de la URL: `drive.google.com/drive/folders/`**`ESTE_ID`**.
3. (Opcional pero recomendado) mueve o crea el Sheet del paso 1 dentro de
   esta misma carpeta, para tener todo junto.

## Paso 3 — Configurar y desplegar el backend (Apps Script)

1. Ve a script.google.com → Nuevo proyecto.
2. Borra el contenido del editor y pega el contenido completo de
   `gas/Code.gs` (de esta copia).
3. Ve al archivo `appsscript.json` (menú ⚙️ Configuración del proyecto →
   marca "Mostrar archivo de manifiesto") y reemplaza su contenido con el
   de `gas/appsscript.json` de esta copia.
4. En `Code.gs`, completa los 3 `TODO` de la sección de configuración
   (arriba del archivo):
   - `DRIVE_ROOT_ID` → el ID del Paso 2.
   - `SIMAT_SHEET_ID` → el ID de tu Sheet SIMAT propio.
   - `FRONTEND_ORIGIN` → lo completas en el Paso 5, cuando sepas tu URL de
     GitHub Pages (mientras tanto puedes dejarlo o poner cualquier valor,
     solo se usa para validar el origen de las subidas de archivos).
5. **Verifica que tu Sheet SIMAT tenga el formato esperado.** El backend
   asume una pestaña llamada `Caldas` con columnas:
   `A: Municipio | B: Institución | C: Sede | ... | P (col. 16): TOTAL (matrícula) | ... | V (col. 22): DANE SEDE`.
   Si tu hoja usa otro nombre de pestaña o otro orden de columnas, ajusta
   la función `leerSimat_()` en `Code.gs` (busca ese nombre en el archivo).
6. Guarda el proyecto y ponle nombre, ej. "Encuesta de daños — Backend".
7. **Ejecuta la inicialización:**
   - En el desplegable de funciones (junto al botón ▷ Ejecutar), elige
     `inicializar`.
   - Haz clic en **Ejecutar**.
   - Aparecerá "Se requiere autorización" → **Revisar permisos** → tu
     cuenta → como el proyecto no está verificado por Google (normal en
     scripts personales), haz clic en **Avanzado** → **Ir a [tu proyecto]
     (no seguro)** → **Permitir**.
   - Esto crea las pestañas `registros`, `padrinos` y `asignacion` en tu
     Sheet de resultados, y siembra `padrinos` con la lista de
     `PADRINOS_SEED` que trae el código (edítala antes de ejecutar si
     quieres tus propios padrinos/contactos).
8. **Despliega como Web App:**
   - Menú **Implementar → Nueva implementación**.
   - Tipo: **Aplicación web**.
   - "Ejecutar como": **Yo** (tu cuenta).
   - "Quién tiene acceso": **Cualquier usuario**.
   - Clic en **Implementar**, autoriza de nuevo si te lo pide.
   - Copia la URL que termina en `/exec`.

## Paso 4 — Conectar el frontend al backend

En `js/config.js` de esta copia, reemplaza el `TODO` de `GAS_URL` con la
URL `/exec` que copiaste en el paso anterior.

Verifica que funcione abriendo en el navegador:

```
TU_URL/exec?accion=catalogos
```

Debe devolver JSON con `"ok":true`.

## Paso 5 — Publicar el frontend en GitHub Pages

1. Crea un repositorio nuevo en GitHub (puede ser público o privado con
   Pages habilitado en un plan que lo permita).
2. Sube todo el contenido de esta carpeta (`index.html`, `dashboard.html`,
   `css/`, `js/`, `favicon.svg` — puedes omitir `gas/` si prefieres
   mantener el backend fuera del repo público, aunque no es sensible una
   vez que quitaste los IDs).
3. En **Settings → Pages**, activa Pages sobre la rama `main`, carpeta raíz.
4. Tu sitio quedará en `https://tuusuario.github.io/turepositorio/`.
5. Vuelve a `Code.gs` (paso 3.4) y actualiza `FRONTEND_ORIGIN` con ese
   dominio (`https://tuusuario.github.io`), luego vuelve a
   **Implementar → Gestionar implementaciones → editar (lápiz) →
   Nueva versión → Implementar** para que el cambio surta efecto.

## Verificación final

- Abre `dashboard.html` de tu sitio publicado: debe cargar (aunque vacío,
  0/0 sedes, hasta que alguien registre una).
- Abre `index.html` (el formulario): el selector de municipios/padrinos
  debe poblarse solo.
- Registra una sede de prueba y confirma que aparece en tu Sheet de
  resultados (pestaña `registros`) y que las evidencias suben a tu carpeta
  de Drive.

## Notas

- El catálogo de 771 sedes de Caldas (municipio → institución → sede) ya
  viene incrustado en `Code.gs` (constante `MUN_IE_SEDE`) — no depende de
  tu Sheet SIMAT en tiempo real; SIMAT solo aporta matrícula y código DANE
  por sede. Si tu operación es en otro departamento o municipios distintos,
  tendrás que reemplazar esa lista por la tuya.
- Modificar el backend más adelante: puedes seguir editando directo en el
  editor de Apps Script (script.google.com), o instalar `clasp` para
  trabajar desde tu máquina — no es obligatorio.
