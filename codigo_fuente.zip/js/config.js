// ================================================
// CONFIGURACIÓN — URL del backend en Google Apps Script
// ================================================
const CONFIG = {
  // TODO: pega aquí la URL /exec de TU propio despliegue de Apps Script
  // (la obtienes al hacer "Implementar → Nueva implementación → Aplicación web").
  GAS_URL: 'https://script.google.com/macros/s/AKfycbzJeQ2XSVs2aADOe2u3BDtnpJT7H40fGayl9NKpU1Z2lLnlEbJt9uvMoPPPb_nA2Wvn/exec',

  // Trozos de 8 MiB para la subida reanudable a Drive (múltiplo de 256 KiB, como exige la API).
  TAMANO_TROZO: 8 * 1024 * 1024,

  // Compresión de fotos en el navegador antes de subirlas.
  FOTO_LADO_MAX: 1920,
  FOTO_CALIDAD: 0.82,
};
